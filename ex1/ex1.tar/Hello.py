#############################################################
# FILE : Hello.py
# WRITER : Yochay Ettun , yochze,  201517018
# EXERCISE : intro2cs ex1 2014-2015
# DESCRIPTION:
# A simple program that prints "Hello World!" to the standard
# output (screen).
#############################################################
print("Hello World!") # Print command
